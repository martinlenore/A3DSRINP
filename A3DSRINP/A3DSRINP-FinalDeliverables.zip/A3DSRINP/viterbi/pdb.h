#ifndef PDB_H
#define PDB_H
#include "vmdplugin.h"
#include "readpdb.h"
#include "periodic_table.h"
#include "largefiles.h"
#include "molfile_plugin.h"

extern molfile_plugin_t plugin;

#endif
